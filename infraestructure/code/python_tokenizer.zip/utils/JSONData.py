class JSONData:
    def __init__(self, name, code, user_id):
        self.name = name
        self.code = code
        self.user_id = user_id

