from utils.DynamoDBManager import DynamoDBManager
from utils.JSONSerializer import JSONSerializer
from python_tokenizer.PyTokenizer import PyTokenizer
from utils.JSONDeserializer import JSONDeserializer
from utils.S3FileRetriver import S3FileRetriever


def lambda_handler(event, context):

    source_code = S3FileRetriever().get_response(event)

    josn_data = JSONDeserializer().deserialize(source_code)
    tokens = PyTokenizer().tokenize(josn_data.code)
    serialized_json = JSONSerializer().serialize(tokens, josn_data.user_id, josn_data.name)

    DynamoDBManager("us-east-1", " tokens-datamart").add_item(serialized_json)


