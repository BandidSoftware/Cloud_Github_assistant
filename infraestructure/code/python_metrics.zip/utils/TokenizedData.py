class TokenizedData:
    def __init__(self, name, tokens, user_id):
        self.name = name
        self.tokens = tokens
        self.user_id = user_id

