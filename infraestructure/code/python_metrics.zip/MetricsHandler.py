from utils.DynamoDBManager import DynamoDBManager
from utils.EvenParser import EventParser
from python_metrics.PyMetrics import PyMetrics
from utils.JSONDeserializer import JSONDeserializer
from utils.JSONSerializer import JSONSerializer


def lambda_handler(event, context):

    user_id, file_name = EventParser().parse_event(event)
    json_string = DynamoDBManager("us-east-1", " tokens-datamart").retrieve_item(user_id, file_name)

    josn_data = JSONDeserializer().deserialize(json_string)
    metrix = PyMetrics().calculate_metrics(josn_data.tokens)
    serialized_json = JSONSerializer().serialize(metrix, josn_data.user_id, josn_data.name)

    DynamoDBManager("us-east-1", " metrics-datamart").add_item(serialized_json)

